package com.example.caribeux.nozzlepage;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.regex.Pattern;

public class Main2Activity extends AppCompatActivity {

    Button cancel, confirm;
    Spinner dropdown;
    String[] types = new String[]{"Vodka", "Tequila", "Gin", "Mixer"};
    ArrayAdapter<String> adapter;
    TextView title;
    EditText content, price;
    AlertDialog.Builder dlgAlert;
    final DecimalFormat df = new DecimalFormat("0.00");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        //Alert Dialog Message Box for errors entering proper format
        dlgAlert = new AlertDialog.Builder(this);

        dropdown = findViewById(R.id.alcoholType);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, types);
        price = findViewById(R.id.alcoholPrice);
        content = findViewById(R.id.alcoholName);
        cancel = findViewById(R.id.btn_cancel);
        confirm = findViewById(R.id.btn_confirm);

        dropdown.setAdapter(adapter);
        title = findViewById(R.id.Activity2MainTitle);

        if (getIntent().getStringExtra("HOSENUM").isEmpty() == false)
            title.setText("Hose " + getIntent().getStringExtra("HOSENUM") + " Configuration");

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity1();
            }
        });

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validEntries()) {
                    System.out.println("Before formatting");
                    String priceValid = df.format(Double.parseDouble(price.getText().toString()));
                    System.out.println("priceValid: " + priceValid);
                    openActivity1(content.getText().toString(), priceValid);
                }
                else {
                    dlgAlert.setMessage("Please enter a valid price: __.__");
                    dlgAlert.setTitle("Incorrect Formatting");
                    dlgAlert.setPositiveButton("Try Again",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    //Dismiss the dialog
                                }
                            });
                    dlgAlert.show();
                }
            }
        });
    }

    public void openActivity1(String name, String price) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_PREVIOUS_IS_TOP);
        intent.putExtra("NAME", name);
        intent.putExtra("PRICE", price);
        intent.putExtra("HOSENUM", getIntent().getStringExtra("HOSENUM"));
        startActivity(intent);
    }

    public void openActivity1() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public boolean validEntries() {
        if (Pattern.matches("[0-9]+(.[0-9][0-9])?", price.getText().toString()))
            return true;
        else
            return false;
    }
}

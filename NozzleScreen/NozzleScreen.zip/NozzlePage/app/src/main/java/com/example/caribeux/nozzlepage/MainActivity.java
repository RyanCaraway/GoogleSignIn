package com.example.caribeux.nozzlepage;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    Button hose1_btn, hose2_btn, hose3_btn, hose4_btn, hose5_btn, hose6_btn, hose7_btn, hose8_btn, confirm_btn;
    TextView content1, content2, content3, content4, content5, content6, content7, content8;
    TextView price1, price2, price3, price4, price5, price6, price7, price8;
    AlertDialog.Builder dlgAlert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setVariables();

        hose1_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity2("1");
            }
        });
        hose2_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity2("2");
            }
        });
        hose3_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity2("3");
            }
        });
        hose4_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity2("4");
            }
        });
        hose5_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity2("5");
            }
        });
        hose6_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity2("6");
            }
        });
        hose7_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity2("7");
            }
        });
        hose8_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity2("8");
            }
        });
        confirm_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dlgAlert.setMessage(getContents());
                dlgAlert.setTitle("Sending Information to Server");
                dlgAlert.show();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        if (somethingSent())
        {
            if (getIntent().getStringExtra("HOSENUM").equals("1"))
            {
                content1.setText(getIntent().getStringExtra("NAME"));
                price1.setText(getIntent().getStringExtra("PRICE"));
            }
            else if (getIntent().getStringExtra("HOSENUM").equals("2"))
            {
                content2.setText(getIntent().getStringExtra("NAME"));
                price2.setText(getIntent().getStringExtra("PRICE"));
            }
            else if (getIntent().getStringExtra("HOSENUM").equals("3"))
            {
                content3.setText(getIntent().getStringExtra("NAME"));
                price3.setText(getIntent().getStringExtra("PRICE"));
            }
            else if (getIntent().getStringExtra("HOSENUM").equals("4"))
            {
                content4.setText(getIntent().getStringExtra("NAME"));
                price4.setText(getIntent().getStringExtra("PRICE"));
            }
            else if (getIntent().getStringExtra("HOSENUM").equals("5"))
            {
                content5.setText(getIntent().getStringExtra("NAME"));
                price5.setText(getIntent().getStringExtra("PRICE"));
            }
            else if (getIntent().getStringExtra("HOSENUM").equals("6"))
            {
                content6.setText(getIntent().getStringExtra("NAME"));
                price6.setText(getIntent().getStringExtra("PRICE"));
            }
            else if (getIntent().getStringExtra("HOSENUM").equals("7"))
            {
                content7.setText(getIntent().getStringExtra("NAME"));
                price7.setText(getIntent().getStringExtra("PRICE"));
            }
            else if (getIntent().getStringExtra("HOSENUM").equals("8"))
            {
                content8.setText(getIntent().getStringExtra("NAME"));
                price8.setText(getIntent().getStringExtra("PRICE"));
            }
        }
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        this.setIntent(intent);
    }

    public void openActivity2(String hose) {
        Intent intent = new Intent(this, Main2Activity.class);
        intent.putExtra("HOSENUM", hose);
        intent.setFlags(intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }

    public boolean somethingSent() {
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null)
            return true;
        else
            return false;
    }

    public void setVariables(){
        content1 = findViewById(R.id.hose1a);
        price1 = findViewById(R.id.hose1b);
        hose1_btn = findViewById(R.id.btn_hose1);

        content2 = findViewById(R.id.hose2a);
        price2 = findViewById(R.id.hose2b);
        hose2_btn = findViewById(R.id.btn_hose2);

        content3 = findViewById(R.id.hose3a);
        price3 = findViewById(R.id.hose3b);
        hose3_btn = findViewById(R.id.btn_hose3);

        content4 = findViewById(R.id.hose4a);
        price4 = findViewById(R.id.hose4b);
        hose4_btn = findViewById(R.id.btn_hose4);

        content5 = findViewById(R.id.hose5a);
        price5 = findViewById(R.id.hose5b);
        hose5_btn = findViewById(R.id.btn_hose5);

        content6 = findViewById(R.id.hose6a);
        price6 = findViewById(R.id.hose6b);
        hose6_btn = findViewById(R.id.btn_hose6);

        content7 = findViewById(R.id.hose7a);
        price7 = findViewById(R.id.hose7b);
        hose7_btn = findViewById(R.id.btn_hose7);

        content8 = findViewById(R.id.hose8a);
        price8 = findViewById(R.id.hose8b);
        hose8_btn = findViewById(R.id.btn_hose8);

        confirm_btn = findViewById(R.id.btn_confirm);
        dlgAlert = new AlertDialog.Builder(MainActivity.this);
    }

    public String getContents(){
        String hose_contents = "";
        hose_contents = hose_contents + "Hose 1 Contents: " + content1.getText() + "\n";
        hose_contents = hose_contents + "Hose 1 Price: " + price1.getText() + "\n";
        hose_contents = hose_contents + "Hose 2 Contents: " + content2.getText() + "\n";
        hose_contents = hose_contents + "Hose 2 Price: " + price2.getText() + "\n";
        hose_contents = hose_contents + "Hose 3 Contents: " + content3.getText() + "\n";
        hose_contents = hose_contents + "Hose 3 Price: " + price3.getText() + "\n";
        hose_contents = hose_contents + "Hose 4 Contents: " + content4.getText() + "\n";
        hose_contents = hose_contents + "Hose 4 Price: " + price4.getText() + "\n";
        hose_contents = hose_contents + "Hose 5 Contents: " + content5.getText() + "\n";
        hose_contents = hose_contents + "Hose 5 Price: " + price5.getText() + "\n";
        hose_contents = hose_contents + "Hose 6 Contents: " + content6.getText() + "\n";
        hose_contents = hose_contents + "Hose 6 Price: " + price6.getText() + "\n";
        hose_contents = hose_contents + "Hose 7 Contents: " + content7.getText() + "\n";
        hose_contents = hose_contents + "Hose 7 Price: " + price7.getText() + "\n";
        hose_contents = hose_contents + "Hose 8 Contents: " + content8.getText() + "\n";
        hose_contents = hose_contents + "Hose 8 Price: " + price8.getText() + "\n";
        hose_contents = hose_contents + "\n** Not really sending data yet **";
        return hose_contents;
    }
}
